package ca.pfv.spmf.algorithms.frequentpatterns.fpgrowth;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import ca.pfv.spmf.algorithms.frequentpatterns.fpgrowth.FPTree;
import ca.pfv.spmf.tools.MemoryLogger;

public class mainfun {
	
	public static String filePathDB;
	public static String filePathW;
	public static String filePathS;
	public static float threshold;
	private static HashMap<Integer,String> idDB;
	private static HashMap<String,Float> itemweight;
	//follow two HashMap are store the connection between itemID int and item string
	private static HashMap<Integer,String> iditem;
	private static HashMap<String,Integer> iditem2;
	//private static HashMap<String,Float> SPrank;
	static Float tsmw;
	
	public static void main(String[] arg) throws IOException {
		
		MemoryLogger.getInstance().reset();
		long startTime = System.nanoTime();
		//filePathDB = "C:\\Users\\ASUS\\Desktop\\full_data_set.txt";
		//filePathDB = "C:\\Users\\ASUS\\Desktop\\test_data_set.txt";
		//filePathDB = "C:\\Users\\ASUS\\Desktop\\human_data.txt";
		filePathDB = "C:\\Users\\ASUS\\Desktop\\uniflna_test01.txt";
		filePathW = "C:\\Users\\ASUS\\Desktop\\itemweight.txt";
		filePathS = "C:\\Users\\ASUS\\Desktop\\pattern2.txt";
		threshold = 0.0f;
				
		//SPrank = new HashMap<String,Float>();
		//String rankpath = "C:\\Users\\ASUS\\Desktop\\rank.txt";
		//String rankpath = "C:\\Users\\ASUS\\Desktop\\rank2.txt";
				
		idDB = readfileDB(filePathDB);
		itemweight = readfileW(filePathW);
		iditem = getitemid(itemweight);
		MemoryLogger.getInstance().checkMemory();//
		HashMap<Integer, Float> seqsmw = calsmw();
		tsmw = caltsmw(seqsmw);
		MemoryLogger.getInstance().checkMemory();//
		//next one is the S-1.1 of BP-CCSM
		HashMap<Integer, Integer> mapSupport = Step11(idDB,iditem);
		MemoryLogger.getInstance().checkMemory();//
		//mapSupport here actually is the head table
		FPTree tree1 = Step12(mapSupport,idDB,iditem);
		MemoryLogger.getInstance().checkMemory();//
		FPTree BEPT = Step2(tree1,mapSupport);
		MemoryLogger.getInstance().checkMemory();//
		BEPT = Step31(BEPT);
		MemoryLogger.getInstance().checkMemory();//
		FPTree FEPT = Step32(BEPT);
		MemoryLogger.getInstance().checkMemory();//
		ArrayList<String> patterns = Step4(FEPT);
		MemoryLogger.getInstance().checkMemory();//
		writefile(filePathS, patterns);
		//writefile2(rankpath,SPrank);
		long endTime   = System.nanoTime();
		long totalTime = endTime - startTime;
		System.out.println(totalTime);
		System.out.println(" Max Memory ~ " + MemoryLogger.getInstance().getMaxMemory() + " MB");
	}
	
	/*public static HashMap<Integer, String> readfileDB(String filepath) {
		HashMap<Integer, String> theidDB = new HashMap<Integer, String>();
		try {
			FileInputStream fin = new FileInputStream(filepath);
			InputStreamReader reader = new InputStreamReader(fin);
			BufferedReader in = new BufferedReader(reader);
			String str = "";
			String temp = "";
			int i = 0;
			while ((temp = in.readLine()) != null) {//now each paragraph is a sequence
				if(temp.charAt(0)!='>') {
					str = str + temp;
				}else {
					theidDB.put(i, str);
					i++;
					str = "";
				}
			}
			in.close();
		} catch (IOException e) {
			e.getStackTrace();
			}
		return theidDB;
		}*/
	
	
	public static HashMap<Integer, String> readfileDB(String filepath) {
		HashMap<Integer, String> theidDB = new HashMap<Integer, String>();
		try {
			FileInputStream fin = new FileInputStream(filepath);
			InputStreamReader reader = new InputStreamReader(fin);
			BufferedReader in = new BufferedReader(reader);
			String temp = "";
			int i = 0;
			while ((temp = in.readLine()) != null) {//now each paragraph is a sequence
				theidDB.put(i, temp);
				i++;
			}
			in.close();
		} catch (IOException e) {
			e.getStackTrace();
			}
		return theidDB;
		}
	
	public static HashMap<String,Float> readfileW(String filepath) {
		HashMap<String, Float> theitemweight = new HashMap<String, Float>();
		try {
			FileInputStream fin = new FileInputStream(filepath);
			InputStreamReader reader = new InputStreamReader(fin);
			BufferedReader in = new BufferedReader(reader);
			//here, i use hashmap to store the weight of item
			String str = "";
			String[] tempArray;

			while ((str = in.readLine()) != null) {//Here, by default, I store the weight of each item in each row, 
				tempArray = str.split(" ");//Weights and items are separated by Spaces
				theitemweight.put(tempArray[0],Float.parseFloat(tempArray[1]));
				//tempArray[0] is the item, tempArray[1] is the weight value of the item

			}
			in.close();
		} catch(IOException e) {
			e.getStackTrace();
		}
		return theitemweight;
	}
	
	public static void writefile(String filePath, ArrayList<String> patterns){

        try{
            File file = new File(filePath);
            FileOutputStream fos = null;
            if(!file.exists()){
                file.createNewFile();
                fos = new FileOutputStream(file);
            }else{
                fos = new FileOutputStream(file,true);
            }
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            for(int i = 0; i<patterns.size();i++){
                String pattern = patterns.get(i);
                osw.write(pattern);
                osw.write("\r\n");
            }
            osw.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public static HashMap<Integer, String> getitemid(HashMap<String,Float> theitemweight){
		HashMap<Integer, String> itemsid = new HashMap<Integer, String>();
		int j = 0;
		iditem2 = new HashMap<String,Integer>();
		for(String i : theitemweight.keySet()) {
			itemsid.put(j,i);
			iditem2.put(i,j);
			j++;
		}
		return itemsid;
	}
	
	public static HashMap<Integer, Integer> Step11(HashMap<Integer,String> SDB, HashMap<Integer,String> IDitem){
		HashMap<Integer, Integer> mapSupport = new HashMap<Integer, Integer>();
		for(Integer i : IDitem.keySet()) {
			String item = IDitem.get(i);
			int count = 0;
			for(Integer j : SDB.keySet()) {
				String seq = SDB.get(j);
				if(seq.contains(item)) {
					count++;
				}
			}
			mapSupport.put(i,count);
		}
		return mapSupport;
		
	}
	

	public static FPTree Step12(HashMap<Integer, Integer> mapSupport, HashMap<Integer,String> SDB, HashMap<Integer,String> IDitem) {
		FPTree tree = new FPTree();
		//tree.createHeaderList(mapSupport);
		for(Integer i : SDB.keySet()) {
			String seq = SDB.get(i);
			ArrayList<Integer> seqlist = new ArrayList<Integer>();
			for(int j = 0;j<seq.length();j++) {
				String item = String.valueOf(seq.charAt(j));
				int id = iditem2.get(item);
				if((((float)mapSupport.get(id))/tsmw)>=threshold) {
					seqlist.add(id);
				}else {
					//discard the infrequent item, and insert the remainder of seq into the root of the tree
					tree.addTransaction(seqlist);
					seqlist = new ArrayList<Integer>();
					continue;
				}
			}
			if(seqlist.isEmpty()) {
				
			}else {
				tree.addTransaction(seqlist);
			}
		}

		return tree;
		
	}
	
	/*public static FPTree Step2(FPTree tree1,HashMap<Integer, Integer> mapSupport) {
		FPTree BEPT = new FPTree();
		//in BP-CCSM paper it doesn't mention about the HT of BEPT, so i use the HT of tree1
		BEPT.createHeaderList(mapSupport);//if i remove this line? since it is useless, i am not very clear the FP-Tree here
		for(Integer id : mapSupport.keySet()) {
			if(mapSupport.get(id)>=threshold) {
				//then i need to DF traverse the tree to find the item n and using its parent to get pi(n)
				Stack<FPNode> stack = new Stack<FPNode>();
				FPNode tempnode = tree1.root;
				stack.push(tempnode);
				while (!stack.isEmpty()) {
					FPNode top = stack.pop();
					if(top.itemID==id) {//add the pi(n) into BEPT
						ArrayList<Integer> seqlist = new ArrayList<Integer>();
						FPNode temp2 = top;
						seqlist.add(temp2.itemID);
						while(temp2.parent!=tree1.root) {
							temp2=temp2.parent;
							seqlist.add(temp2.itemID);
						}
						BEPT.addTransaction(seqlist);
					}
					List<FPNode> children = top.childs;
					if (children != null && children.size() > 0) {
						for (int i = children.size() - 1; i >= 0; i--) {
							stack.push(children.get(i));
						}
					}
				}
			}
		}
 		return BEPT;
	}*/
	
	public static FPTree Step2(FPTree tree1,HashMap<Integer, Integer> mapSupport) {
		//System.out.println(mapSupport);
		FPTree BEPT = new FPTree();
		for(Integer id : mapSupport.keySet()) {
			if((((float)mapSupport.get(id))/tsmw)>=threshold) {
				FPNode node = tree1.mapItemNodes.get(id);
				//System.out.println(node.itemID);
				//System.out.println(node.nodeLink);
				while((node!=null)&&(node.nodeLink!=null)) {//for each n is the linked-list of n in HT
					//System.out.println(node.itemID);
					List<FPNode> seqlist = new ArrayList<FPNode>();
					Map<Integer, Integer> temp2 = new HashMap<Integer, Integer>();
					FPNode temp = node;
					seqlist.add(temp);
					temp2.put(temp.itemID,1);
					while(temp.parent!=null) {//add the pi(n) into BEPT
						temp=temp.parent;
						seqlist.add(temp);
						temp2.put(temp.itemID,1);
					}
					//System.out.println(seqlist);
					BEPT.addPrefixPath(seqlist,temp2,0,2);
					node = node.nodeLink;
				}
			}
		}
		//System.out.println(BEPT);
		return BEPT;
	}
	
	
	public static FPTree Step31(FPTree BEPT) {
		//first traverse the tree to find the item(node) that count smaller than threshold
		BEPT.root.counter = -1;//counter of root set -1!
		Stack<FPNode> stack = new Stack<FPNode>();
		stack.push(BEPT.root);
		int parentsupport = -1;//counter of root set -1!
		while (!stack.isEmpty()) {
			FPNode top = stack.pop();
			if(((((float)top.counter)/tsmw)>=threshold)||(top.counter==-1)) {
				//also the closure check will be added
				List<FPNode> children = top.childs;
				if (children != null && children.size() > 0) {
					for (int i = children.size() - 1; i >= 0; i--) {
						if(children.get(i).counter==parentsupport) {//not closed
							/*delete the item(node) n
							FPNode node = top.parent;
							for(int j = 0;j<=top.childs.size();j++) {
								node.childs.add(top.childs.get(j));
							}*/
							top.isclosed = -1;
						}
					}
				}
			}else {//infrequent
				/*delete the item(node) n
				FPNode node = top.parent;
				for(int j = 0;j<=top.childs.size();j++) {
					node.childs.add(top.childs.get(j));
				}*/
				top.isclosed = -1;
			}
			List<FPNode> children2 = top.childs;
			parentsupport = top.counter;
			if (children2 != null && children2.size() > 0) {
				for (int i = children2.size() - 1; i >= 0; i--) {
					stack.push(children2.get(i));
				}
			}
			
		}
		return BEPT;
	}
	
	public static FPTree Step32(FPTree BEPT) {
		FPTree FEPT = new FPTree();
		//here i didn't create the head table for FEPT. i don't clear whether it will cause bug...
		Stack<FPNode> stack = new Stack<FPNode>();
		stack.push(BEPT.root);
		while (!stack.isEmpty()) {
			FPNode top = stack.pop();//for every item (node)
			if(top.itemID!=-1) {
				if(top.isclosed==1) {
					List<FPNode> Pin = new ArrayList<FPNode>();
					Map<Integer, Integer> temp2 = new HashMap<Integer, Integer>();
					FPNode temp = top;
					temp2.put(top.itemID,1);
					Pin.add(temp);
					while(temp.parent!=BEPT.root) {
						temp=temp.parent;
						temp2.put(temp.itemID,1);
						Pin.add(temp);
					}
					//List<FPNode> rePin = reverse(Pin);
					FEPT.addPrefixPath(Pin,temp2,0,1);
				}else {
					//this node is pruned
				}
			}
			List<FPNode> children = top.childs;
			if (children != null && children.size() > 0) {
				for (int i = children.size() - 1; i >= 0; i--) {
					stack.push(children.get(i));
				}
			}
		}
		return FEPT;
	}
	
	/*public static List<FPNode> reverse(List<FPNode> Pin){
		List<FPNode> rePin = new ArrayList<FPNode>();
		for(int i = Pin.size()-1; i>=0;i--) {
			rePin.add(Pin.get(i));
		}
		return rePin;
	}*/
	
	public static ArrayList<String> Step4(FPTree FEPT){
		ArrayList<String> patterns = new ArrayList<String>();
		FEPT.root.counter = -1;//counter of root set -1!
		Stack<FPNode> stack = new Stack<FPNode>();
		stack.push(FEPT.root);
		int parentsupport = -1;//counter of root set -1!
		while (!stack.isEmpty()) {
			FPNode top = stack.pop();
			//also the closure check will be added
			List<FPNode> children = top.childs;
			if (children != null && children.size() > 0) {
				for (int i = children.size() - 1; i >= 0; i--) {
					if(children.get(i).counter==parentsupport) {
						/*delete the item(node) n
						FPNode node = top.parent;
						for(int j = 0;j<=top.childs.size();j++) {
							node.childs.add(top.childs.get(j));
						}*/
						top.isclosed = -1;
					}
				}
			}
			List<FPNode> children1 = top.childs;
			parentsupport = top.counter;
			if (children1 != null && children1.size() > 0) {
				for (int i = children1.size() - 1; i >= 0; i--) {
					stack.push(children1.get(i));
				}
			}
		}
		//next is the pseudo code of algorithm 1 of original paper
		Stack<FPNode> S = new Stack<FPNode>();
		S.push(FEPT.root);
		while (!S.isEmpty()) {
			FPNode top = S.pop();
			if(top.isclosed==1) {
				FPNode temp = top;
				String pattern = new String();
				pattern = pattern + iditem.get(temp.itemID);
				while((temp.parent!=FEPT.root)&&(temp!=FEPT.root)) {
					temp = temp.parent;
					pattern = pattern + iditem.get(temp.itemID);//because it is depth-first so the ending will automatically closed
				}
				if(pattern!=null) {
					patterns.add(pattern);
					//SPrank.put(pattern,((float) temp.counter/tsmw));
				}
		
			}
			List<FPNode> children2 = top.childs;
			if (children2 != null && children2.size() > 0) {
				for (int i = children2.size() - 1; i >= 0; i--) {
					S.push(children2.get(i));
				}
			}
		}
		return patterns;
	}
	
	/*public static void writefile2(String filePath, HashMap<String,Float> SPrank){

        try{
            File file = new File(filePath);
            FileOutputStream fos = null;
            if(!file.exists()){
                file.createNewFile();
                fos = new FileOutputStream(file);
            }else{
                fos = new FileOutputStream(file,true);
            }
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            for(String SP : SPrank.keySet()){
                Float support = SPrank.get(SP);
                String thispair = SP + "-" + Float.toString(support);
                osw.write(thispair);
                osw.write("\r\n");
            }
            osw.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }*/
	
	//from prefix-extend method 
	public static HashMap<Integer,Float> calsmw(){//calculate the smw of each seq in DB
		HashMap<Integer, Float> seqsmw = new HashMap<Integer, Float>();
		//debug 1 
		//System.out.print(idDB.size());
		for(int i = 0; i < idDB.size(); i++){
			String str = idDB.get(i);
			float thissmw = 0f;
			for(int j = 0; j<str.length();j++) {
				String s = String.valueOf(str.charAt(j));
				if(itemweight.get(s)>thissmw) {
					thissmw = itemweight.get(s);
				}
			}
			seqsmw.put(i,thissmw);
		} 
		return seqsmw;
	}
	
	public static Float caltsmw(HashMap<Integer,Float> seqsmw) {
		Float tsmw = 0f;
		for(int i=0; i < seqsmw.size();i++) {
			tsmw = tsmw + seqsmw.get(i);
		}
		return tsmw;
	}

}
