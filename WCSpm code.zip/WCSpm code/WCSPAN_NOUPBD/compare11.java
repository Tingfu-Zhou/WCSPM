package ca.pfv.spmf.algorithms.frequentpatterns.foshu;


import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;

import ca.pfv.spmf.tools.MemoryLogger;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;

public class compare11 {
	static Float tsmw;
	static HashMap<Integer, Float> seqsmw;
	public static HashMap<String,Float> itemweight;

	public static String filePathS;
	public static float threshold;
	static String prefix;
	static Float prefixwsup;
	static HashMap<Integer,String> prefixDB;
	static HashMap<String,Integer> thetemp;
	//note that the key of prefixDB is not the sequence ID due to the HashMap collision, and the key
	//of HashMap thetemp is the projected sequence and its value is the sequence ID

	
	public static void main() throws IOException {
		filePathS = "C:\\Users\\ASUS\\Desktop\\pattern3.txt";
		ArrayList<String> SP = new ArrayList<String>();

		for(Integer i : prefixDB.keySet()) {
			String proseq = prefixDB.get(i);
			if(proseq == null) {
				continue;
			}
			if(proseq.length()==0) {
				continue;
			}
			char firstitem = proseq.charAt(0);
			String candidate = prefix + String.valueOf(firstitem);
			if(isunique(candidate,SP)) {
				//if(UBcheck(lastUBSP,candidate)) {
				Float wsup = calwsup(candidate, tsmw, prefixDB);
					if((wsup>=threshold)&&BackwardCheck(prefixwsup,wsup)) {
						SP.add(candidate);
					}
					//thetemp = new HashMap<String,Integer>();
					HashMap<Integer,String> newpDB = projectedDB(candidate);
					//prefix-extend

					if(newpDB.size()==0) {
						continue;
					}
					compare11.prefix = candidate;
					compare11.prefixDB = newpDB;
					compare11.prefixwsup = wsup;
					MemoryLogger.getInstance().checkMemory();//
					compare11.main();
					
				//}
			}
		}
		writefile(filePathS, SP);
	}
	
	public static void writefile(String filePath, ArrayList<String> patterns){

        try{
            File file = new File(filePath);
            FileOutputStream fos = null;
            if(!file.exists()){
                file.createNewFile();
                fos = new FileOutputStream(file);
            }else{
                fos = new FileOutputStream(file,true);
            }
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            for(int i = 0; i<patterns.size();i++){
                String pattern = patterns.get(i);
                osw.write(pattern);
                osw.write("\r\n");
            }
            osw.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	private static boolean isunique(String candidate, ArrayList<String> candidateset) {
		if(candidateset==null) {
			return true;
		}else {
		for(int i = 0;i<candidateset.size();i++) {
			String temp = candidateset.get(i);
			if(candidate == temp) {
				return false;
			}
		}
		return true;
	}
		}
	
	/*private static boolean UBcheck(ArrayList<String> nUBSP, String candidate) {
		String presub = removeCharAt(candidate,candidate.length()-1);
		String postsub = removeCharAt(candidate,0);
		if((nUBSP.contains(presub))&&(nUBSP.contains(postsub))) {
			return true;
		}else {
			return false;
		}
	}*/
	
	public static String removeCharAt(String s, int pos) {
		return s.substring(0, pos) + s.substring(pos + 1);
	}
	
	private static boolean BackwardCheck(Float oldwsup, Float newwsup) {
		if(oldwsup==newwsup) {
			return false;
		}
		return true;
	}
	
	private static Float calwsup(String s, Float tsmw, HashMap<Integer,String> DB) {
		//here this function only used in Main-Fun. In Find-SP the calwsup function will enhance the method to
		//find which sequence contain the candidate
		//first calculate weighted value of the candidate.
		Float Ws = calwv(s);
		//then check the num of seq that conatain s
		int num = quickcontain(s,DB);//!note the database DB here is projected DB of (old) prefix
		Float wsup = (Ws*num)/tsmw;
		return wsup;
	}
	
	private static Integer quickcontain(String s, HashMap<Integer,String> DB) {
		int index = s.length()- 1;
		char item = s.charAt(index);
		ArrayList<Integer> idlist = new ArrayList<Integer>();
		int num = 0;
		for(Integer i : DB.keySet()) {
			String proseq = DB.get(i);
			int seqID = thetemp.get(proseq);
			
			if(proseq.length()==0) {
				continue;
			}
			if((proseq.charAt(0)==item)&&(unique(seqID,idlist))) {
				idlist.add(seqID);
				num++;
			}
		}
		return num;
	}
	
	private static boolean unique(Integer A, ArrayList<Integer> B) {
		if(B==null) {
			return true;
		}else {
		for(int i = 0;i<B.size();i++) {
			Integer temp = B.get(i);
			if(A == temp) {
				return false;
			}
		}
		return true;
	}
		}
	
	private static Float calwv(String s) {
		Float totalw = (float) 0;
		for(int i = 0; i<s.length();i++) {
			String item = String.valueOf(s.charAt(i));
			totalw = totalw + itemweight.get(item);
		}
		totalw = totalw/((float)s.length());
		return totalw;
	}
	

	
	public static HashMap<Integer,String> projectedDB(String prefix){
		//here, different with the projectedDB function in main-fun the DB here is projected DB
		HashMap<Integer,String> newpDB = new HashMap<Integer,String>();
		int index = prefix.length()- 1;
		char item = prefix.charAt(index);
		HashMap<String,Integer> newthetemp = new HashMap<String,Integer>();

		for(Integer i : prefixDB.keySet()) {
			String oldproseq = prefixDB.get(i);
			if(oldproseq.length()==0) {
				continue;
			}
			char tempitem = oldproseq.charAt(0);
			if(tempitem==item) {
				String newprojectseq = oldproseq.substring(1,oldproseq.length());
				if(newprojectseq.length()>=0) {
					newpDB.put(i,newprojectseq);
					int id = thetemp.get(oldproseq);
					newthetemp.put(newprojectseq, id);
				}
			}
		}
		thetemp = newthetemp;
		MemoryLogger.getInstance().checkMemory();//
		return newpDB;
	}
}


