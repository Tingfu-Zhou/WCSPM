package ca.pfv.spmf.algorithms.frequentpatterns.foshu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import ca.pfv.spmf.tools.MemoryLogger;



public class compare1 {
	
	public static String filePathDB;
	public static String filePathW;
	public static String filePathS;
	public static float threshold;
	private static HashMap<Integer,String> idDB;
	private static HashMap<String,Float> itemweight;
	private static HashMap<Integer,String> iditem;
	private static HashMap<String,Integer> thetemp;
	
	public static void main(String[] arg) throws IOException {
		
		MemoryLogger.getInstance().reset();
		long startTime = System.nanoTime();
		//filePathDB = "C:\\Users\\ASUS\\Desktop\\full_data_set.txt";
		//filePathDB = "C:\\Users\\ASUS\\Desktop\\test_data_set.txt";
		//filePathDB = "C:\\Users\\ASUS\\Desktop\\human_data.txt";
		//filePathDB = "C:\\Users\\ASUS\\Desktop\\peptide.txt";
		filePathDB = "C:\\Users\\ASUS\\Desktop\\T1test.txt";
		filePathW = "C:\\Users\\ASUS\\Desktop\\itemweight.txt";
		filePathS = "C:\\Users\\ASUS\\Desktop\\pattern3.txt";
		threshold = 0.075f;
		idDB = readfileDB(filePathDB);
		itemweight = readfileW(filePathW);
		iditem = getitemid(itemweight);
		ArrayList<String> SP = new ArrayList<String>();
		MemoryLogger.getInstance().checkMemory();//
		HashMap<Integer, Float> seqsmw = calsmw();
		Float tsmw = caltsmw(seqsmw);
		//here i use String to represent sequence, Arraylist<String> repsent
		for(int i = 0; i<iditem.size();i++) {
			String item = iditem.get(i);
			Float wsup = calwsup(item, tsmw, idDB);
			if(wsup>threshold) {
				SP.add(item);
			}
			

			thetemp = new HashMap<String,Integer>();
 			HashMap<Integer,String> pDB = projectedDB(item);

			/*!!one problem is that due to the hash collision,the key of the hashmap is not the id of the seq
			* thus another hashmap is used to connect the projected sequence and the sequence ID */
				
			//prefix-extend(pDB,item,thetemp)��
			compare11.tsmw = tsmw;
			compare11.seqsmw = seqsmw;
			compare11.itemweight = itemweight;
			compare11.filePathS = filePathS;
			compare11.threshold = threshold;
			compare11.prefix = item;
			compare11.prefixDB = pDB;
			compare11.prefixwsup = wsup;
			compare11.thetemp = thetemp;
			MemoryLogger.getInstance().checkMemory();//
			compare11.main();
			
		}
		writefile(filePathS, SP);
		long endTime   = System.nanoTime();
		long totalTime = endTime - startTime;
		System.out.println(totalTime);
		System.out.println(" Max Memory ~ " + MemoryLogger.getInstance().getMaxMemory() + " MB");
	}
	
	/*public static HashMap<Integer, String> readfileDB(String filepath) {
		HashMap<Integer, String> theidDB = new HashMap<Integer, String>();
		try {
			FileInputStream fin = new FileInputStream(filepath);
			InputStreamReader reader = new InputStreamReader(fin);
			BufferedReader in = new BufferedReader(reader);
			String str = "";
			String temp = "";
			int i = 0;
			while ((temp = in.readLine()) != null) {//now each paragraph is a sequence
				if(temp.charAt(0)!='>') {
					str = str + temp;
				}else {
					theidDB.put(i, str);
					i++;
					str = "";
				}
			}
			in.close();
		} catch (IOException e) {
			e.getStackTrace();
			}
		return theidDB;
		}*/
	
	public static HashMap<Integer, String> readfileDB(String filepath) {
		HashMap<Integer, String> theidDB = new HashMap<Integer, String>();
		try {
			FileInputStream fin = new FileInputStream(filepath);
			InputStreamReader reader = new InputStreamReader(fin);
			BufferedReader in = new BufferedReader(reader);
			String temp = "";
			int i = 0;
			while ((temp = in.readLine()) != null) {//now each paragraph is a sequence
				theidDB.put(i, temp);
				i++;
			}
			in.close();
		} catch (IOException e) {
			e.getStackTrace();
			}
		return theidDB;
		}
	
	public static HashMap<String,Float> readfileW(String filepath) {
		HashMap<String, Float> theitemweight = new HashMap<String, Float>();
		try {
			FileInputStream fin = new FileInputStream(filepath);
			InputStreamReader reader = new InputStreamReader(fin);
			BufferedReader in = new BufferedReader(reader);
			//here, i use hashmap to store the weight of item
			String str = "";
			String[] tempArray;
			int i = 0;
			while ((str = in.readLine()) != null) {//Here, by default, I store the weight of each item in each row, 
				tempArray = str.split(" ");//Weights and items are separated by Spaces
				theitemweight.put(tempArray[0],Float.parseFloat(tempArray[1]));
				//tempArray[0] is the item, tempArray[1] is the weight value of the item
				i++;
			}
			in.close();
		} catch(IOException e) {
			e.getStackTrace();
		}
		return theitemweight;
	}
	
	public static void writefile(String filePath, ArrayList<String> patterns){

        try{
            File file = new File(filePath);
            FileOutputStream fos = null;
            if(!file.exists()){
                file.createNewFile();
                fos = new FileOutputStream(file);
            }else{
                fos = new FileOutputStream(file,true);
            }
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            for(int i = 0; i<patterns.size();i++){
                String pattern = patterns.get(i);
                osw.write(pattern);
                osw.write("\r\n");
            }
            osw.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public static HashMap<Integer, String> getitemid(HashMap<String,Float> theitemweight){
		HashMap<Integer, String> itemsid = new HashMap<Integer, String>();
		int j = 0;
		for(String i : theitemweight.keySet()) {
			itemsid.put(j,i);
			j++;
		}
		return itemsid;
	}
	
	public static HashMap<Integer,Float> calsmw(){//calculate the smw of each seq in DB
		HashMap<Integer, Float> seqsmw = new HashMap<Integer, Float>();
		//debug 1 
		//System.out.print(idDB.size());
		for(int i = 0; i < idDB.size(); i++){
			String str = idDB.get(i);
			float thissmw = 0f;
			for(int j = 0; j<str.length();j++) {
				String s = String.valueOf(str.charAt(j));
				if(itemweight.get(s)>thissmw) {
					thissmw = itemweight.get(s);
				}
			}
			seqsmw.put(i,thissmw);
		}
		MemoryLogger.getInstance().checkMemory();//
		return seqsmw;
	}
	
	public static Float caltsmw(HashMap<Integer,Float> seqsmw) {
		Float tsmw = 0f;
		for(int i=0; i < seqsmw.size();i++) {
			tsmw = tsmw + seqsmw.get(i);
		}
		return tsmw;
	}
	
	public static Float calwsup(String s, Float tsmw, HashMap<Integer,String> DB) {
		//here this function only used in Main-Fun. In Find-SP the calwsup function will enhance the method to
		//find which sequence contain the candidate
		//first calculate weighted value of the candidate.
		Float Ws = calwv(s);
		//then check the num of seq that conatain s
		int num = quickcontain(s,DB);
		Float wsup = (Ws*num)/tsmw;
		return wsup;
	}
	

	
	public static Integer quickcontain(String s, HashMap<Integer,String> DB) {
		//this contain function only check the number of seq that contain the candidate
		Integer num = 0;
		for(int i = 0; i<DB.size();i++) {
			String seq = DB.get(i);
			if(seq.contains(s)) {
				num++;
			}
		}
		return num;
	}
	
	public static Float calwv(String s) {
		Float totalw = 0f;
		for(int i = 0; i<s.length();i++) {
			String item = String.valueOf(s.charAt(i));
			totalw = totalw + itemweight.get(item);
		}
		totalw = totalw/((float)s.length());
		return totalw;
	}
	
	//these ten functions above is copied from wcspan
	
	public static HashMap<Integer,String> contain(String s, HashMap<Integer,String> DB) {/*this function is only used for main-fun,
	    the length of String s here is 1.*/
		/*the hashmap "seqcontain" is used to store the sequence'id that coantain the candidate s,
		 *  and the String in the hashmap is the position that candidiate "s" shown in the sequence.
		 *   For example seq1="abcdasd", the length 1 candidate is "a" which shown in the seq1 at 
		 *   position 0 and 4, thus the String "position" in hashmap is "04".The reason of why storing
		 *   the position is that in Find-SP of the "s", it can be easily find which sequence contain 
		 *   the adjacent candidates (of "s") by checkingthe sequence of the hashmap "seqcontain" of
		 *    "s" and the position of the sequence due to the relation which explained at theorem 1*/
		HashMap<Integer, String> seqcontain = new HashMap<Integer, String>();
		for(int i = 0; i<DB.size();i++) {//here, "i" is the id of the sequence in DB
			String seq = DB.get(i);
			String position = "";//here, "position" mean the place that "s" shown in this sequence
			int iscontain = 0;
			for(int j = 0; j<seq.length();j++) {
				String item = String.valueOf(seq.charAt(j));
				if(s.equals(item)) {//Note that this contain function is only fit of length-1 checking
					position = position + String.valueOf(j) + "-";
					iscontain = 1;
				}
			}
			if(iscontain==1) {
				seqcontain.put(i, position);
			}
		}
		MemoryLogger.getInstance().checkMemory();//
		return seqcontain;
	}
	
	public static HashMap<Integer,String> projectedDB(String prefix){
		HashMap<Integer,String> pDB = new HashMap<Integer,String>();
		HashMap<Integer,String> allpositions = contain(prefix,idDB);

		int j = 0;
		for(Integer id : allpositions.keySet()) {
			String position = allpositions.get(id);
			String tempindex = new String();
			for(int i = 0;i<position.length();i++) {
				char temp = position.charAt(i);
				
				if(temp!='-') {
					tempindex = tempindex + String.valueOf(temp);
				}else {
					int index = Integer.parseInt(tempindex);
					String seq = idDB.get(id);
					int last = seq.length();
					String projectseq = seq.substring((index+1),last);
					if(projectseq.length()>=0) {
						pDB.put(j,projectseq);
						j++;
						thetemp.put(projectseq, id);
					}
					tempindex = new String();
				}
			}
		}
		MemoryLogger.getInstance().checkMemory();//
		return pDB;
	}
}
