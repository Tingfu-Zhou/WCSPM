package ca.pfv.spmf.algorithms.frequentpatterns.fpgrowth_with_strings;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;

import ca.pfv.spmf.tools.MemoryLogger;


public class mainfun {
	
	public static String filePathDB;
	public static String filePathW;
	public static String filePathS;
	public static float threshold;
	private static HashMap<Integer,String> idDB;
	public static HashMap<String,Integer> DBid;//
	private static HashMap<String,Float> itemweight;
	private static HashMap<Integer,String> iditem;
	
	
	public static void main(String[] arg) throws IOException {
		
		MemoryLogger.getInstance().reset();
		long startTime = System.nanoTime();
		//first is read in file
		//including the original database DB, and the weight of each item
		//filePathDB = "C:\\Users\\ASUS\\Desktop\\full_data_set.txt";
		//filePathDB = "C:\\Users\\ASUS\\Desktop\\test_data_set.txt";//i am not sure whether the path is right
		//filePathDB = "C:\\Users\\ASUS\\Desktop\\human_data.txt";
		filePathDB = "C:\\Users\\ASUS\\Desktop\\peptide.txt";
		filePathW = "C:\\Users\\ASUS\\Desktop\\itemweight.txt";
		filePathS = "C:\\Users\\ASUS\\Desktop\\pattern4.txt";
		threshold = 0.0f;
		DBid = new HashMap<String,Integer>();
		idDB = readfileDB(filePathDB);
		//debug test

		itemweight = readfileW(filePathW);

		//Initialize the SP and UBSP
		iditem = getitemid(itemweight);

		ArrayList<String> SP = new ArrayList<String>();
		ArrayList<String> UBSP = new ArrayList<String>();
		//calculate the smw and tsmw of DB
		HashMap<Integer, Float> seqsmw = calsmw();
		Float tsmw = caltsmw(seqsmw);

		for(int i = 0; i<iditem.size();i++) {
			String item = iditem.get(i);
			if(calwsup(item, tsmw, idDB)) {
				SP.add(item);
			}
			if(calswub(item, tsmw, idDB, seqsmw)) {
				UBSP.add(item);
			}
		}
		for(int m = 0; m<UBSP.size();m++) {
			String item = UBSP.get(m);
			HashMap<Integer, String> seqcontain = contain(item, idDB);
			HashMap<Integer, String> itemDB = new HashMap<Integer, String>();
			for (Integer j : seqcontain.keySet()) {
				String seq = idDB.get(j);
				if(seq.length()>=2) {
					itemDB.put(j, seq);
					//the id of the sequence in itemDB is the same as the id of the sequence in idDB
				}
			}
			//Find-SP(), here i import find-sp class
			findsp.threshold = threshold;
			findsp.filePathS = filePathS;
			findsp.itemweight = itemweight;
			findsp.DBid	= DBid;//
			findsp.itemDB = itemDB;
			//findsp.lastUBSP = UBSP;
			findsp.seqcontain = seqcontain;
			findsp.seqsmw = seqsmw;
			findsp.n = 1;
			findsp.e = item;
			findsp.tsmw = tsmw;
			MemoryLogger.getInstance().checkMemory();//
			findsp.main();
		}
		
		writefile(filePathS, SP);
		long endTime   = System.nanoTime();
		long totalTime = endTime - startTime;
		System.out.println(totalTime);
		System.out.println(" Max Memory ~ " + MemoryLogger.getInstance().getMaxMemory() + " MB");
	}

	/*public static HashMap<Integer, String> readfileDB(String filepath) {
		HashMap<Integer, String> theidDB = new HashMap<Integer, String>();
		try {
			FileInputStream fin = new FileInputStream(filepath);
			InputStreamReader reader = new InputStreamReader(fin);
			BufferedReader in = new BufferedReader(reader);
			String str = "";
			String temp = "";
			int i = 0;
			while ((temp = in.readLine()) != null) {//now each paragraph is a sequence
				if(temp.charAt(0)!='>') {
					str = str + temp;
				}else {
					theidDB.put(i, str);
					i++;
					str = "";
				}
			}
			in.close();
		} catch (IOException e) {
			e.getStackTrace();
			}
		return theidDB;
		}*/
	
	public static HashMap<Integer, String> readfileDB(String filepath) {
		HashMap<Integer, String> theidDB = new HashMap<Integer, String>();
		try {
			FileInputStream fin = new FileInputStream(filepath);
			InputStreamReader reader = new InputStreamReader(fin);
			BufferedReader in = new BufferedReader(reader);
			String temp = "";
			int i = 0;
			while ((temp = in.readLine()) != null) {//now each paragraph is a sequence
				theidDB.put(i, temp);
				DBid.put(temp, i);//
				i++;
			}
			in.close();
		} catch (IOException e) {
			e.getStackTrace();
			}
		return theidDB;
		}
	
	
	public static HashMap<String,Float> readfileW(String filepath) {
		HashMap<String, Float> theitemweight = new HashMap<String, Float>();
		try {
			FileInputStream fin = new FileInputStream(filepath);
			InputStreamReader reader = new InputStreamReader(fin);
			BufferedReader in = new BufferedReader(reader);
			//here, i use hashmap to store the weight of item
			String str = "";
			String[] tempArray;

			while ((str = in.readLine()) != null) {//Here, by default, I store the weight of each item in each row, 
				tempArray = str.split(" ");//Weights and items are separated by Spaces
				theitemweight.put(tempArray[0],Float.parseFloat(tempArray[1]));
				//tempArray[0] is the item, tempArray[1] is the weight value of the item

			}
			in.close();
		} catch(IOException e) {
			e.getStackTrace();
		}
		return theitemweight;
	}
	
	public static HashMap<Integer, String> getitemid(HashMap<String,Float> theitemweight){
		HashMap<Integer, String> itemsid = new HashMap<Integer, String>();
		int j = 0;
		for(String i : theitemweight.keySet()) {
			itemsid.put(j,i);
			j++;
		}
		return itemsid;
	}
	
	public static void writefile(String filePath, ArrayList<String> patterns){

        try{
            File file = new File(filePath);
            FileOutputStream fos = null;
            if(!file.exists()){
                file.createNewFile();
                fos = new FileOutputStream(file);
            }else{
                fos = new FileOutputStream(file,true);
            }
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            for(int i = 0; i<patterns.size();i++){
                String pattern = patterns.get(i);
                osw.write(pattern);
                osw.write("\r\n");
            }
            osw.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public static HashMap<Integer,Float> calsmw(){//calculate the smw of each seq in DB
		HashMap<Integer, Float> seqsmw = new HashMap<Integer, Float>();
		//debug 1 
		//System.out.print(idDB.size());
		for(int i = 0; i < idDB.size(); i++){
			String str = idDB.get(i);
			float thissmw = 0f;
			for(int j = 0; j<str.length();j++) {
				String s = String.valueOf(str.charAt(j));
				if(itemweight.get(s)>thissmw) {
					thissmw = itemweight.get(s);
				}
			}
			seqsmw.put(i,thissmw);
		}
		MemoryLogger.getInstance().checkMemory();//
		return seqsmw;
	}
	
	public static Float caltsmw(HashMap<Integer,Float> seqsmw) {
		Float tsmw = 0f;
		for(int i=0; i < seqsmw.size();i++) {
			tsmw = tsmw + seqsmw.get(i);
		}
		return tsmw;
	}
	
	public static Float calwv(String s) {
		Float totalw = 0f;
		for(int i = 0; i<s.length();i++) {
			String item = String.valueOf(s.charAt(i));
			totalw = totalw + itemweight.get(item);
		}
		totalw = totalw/((float)s.length());
		return totalw;
	}
	
	public static HashMap<Integer,String> contain(String s, HashMap<Integer,String> DB) {/*this function is only used for main-fun,
	    the length of String s here is 1.*/
		/*the hashmap "seqcontain" is used to store the sequence'id that coantain the candidate s,
		 *  and the String in the hashmap is the position that candidiate "s" shown in the sequence.
		 *   For example seq1="abcdasd", the length 1 candidate is "a" which shown in the seq1 at 
		 *   position 0 and 4, thus the String "position" in hashmap is "0-4-".The reason of why storing
		 *   the position is that in Find-SP of the "s", it can be easily find which sequence contain 
		 *   the adjacent candidates (of "s") by checkingthe sequence of the hashmap "seqcontain" of
		 *    "s" and the position of the sequence due to the relation which explained at theorem 1*/
		HashMap<Integer, String> seqcontain = new HashMap<Integer, String>();
		for(int i = 0; i<DB.size();i++) {//here, "i" is the id of the sequence in DB
			String seq = DB.get(i);
			String position = "";//here, "position" mean the place that "s" shown in this sequence
			int iscontain = 0;
			for(int j = 0; j<seq.length();j++) {
				String item = String.valueOf(seq.charAt(j));
				if(s.equals(item)) {//Note that this contain function is only fit of length-1 checking
					position = position + String.valueOf(j) + "-";
					iscontain = 1;
				}
			}
			if(iscontain==1) {
				seqcontain.put(i, position);
			}
		}
		MemoryLogger.getInstance().checkMemory();//
		return seqcontain;
	}
	
	public static Integer quickcontain(String s, HashMap<Integer,String> DB) {
		//this contain function only check the number of seq that contain the candidate
		Integer num = 0;
		for(int i = 0; i<DB.size();i++) {
			String seq = DB.get(i);
			if(seq.contains(s)) {
				num++;
			}
		}
		return num;
	}
	
	public static boolean calwsup(String s, Float tsmw, HashMap<Integer,String> DB) {
		//here this function only used in Main-Fun. In Find-SP the calwsup function will enhance the method to
		//find which sequence contain the candidate
		//first calculate weighted value of the candidate.
		Float Ws = calwv(s);
		//then check the num of seq that conatain s
		int num = quickcontain(s,DB);
		Float wsup = (Ws*num)/tsmw;
		if(wsup>threshold) {
			return true;
		}else {
			return false;
		}
	}
	
	public static boolean calswub(String s, Float tsmw, HashMap<Integer,String> DB, HashMap<Integer,Float> smw){
		/*???here this function i didn't use inheritance and polymorphism to return boolean and "seqcontain" hashmap
		 * which can Simplify the code
		 * i am not sure whether it will effect the efficiency of algorithm*/
		HashMap<Integer, String> seqcontain = contain(s, DB);

		Float totalsmw = 0f;
		for(Integer i : seqcontain.keySet()) {
			totalsmw = totalsmw + smw.get(i);
		}
		Float swub = totalsmw/tsmw;
		if(swub>threshold) {
			return true;
		}else {
			return false;
		}
	}
	
}
