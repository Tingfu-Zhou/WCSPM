package ca.pfv.spmf.algorithms.frequentpatterns.fpgrowth_with_strings;


import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;

import ca.pfv.spmf.tools.MemoryLogger;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;

/*here i am not familiar with the operation of eclipse, so i put the Find-SP function into a class
 * the input of Find-SP function including the UBSP pattern "e", the relative database "DB_e"(which in 
 * this code is divided into "seqcontain" and "itemDB" two parts), the length "n" of "e" and the threshold
 * also including the smw of each seq. Note that the sequential id of hashmap "seqcontain" and "seqsmw" is
 * the same as the sequential id in itemDB*/
public class findsp {

	public static String filePathS;
	public static float threshold;
	public static HashMap<String,Integer> DBid;//
    static HashMap<Integer,String> itemDB;
	//itemDB is the database of the sequence that contain the pattern "e";
	static HashMap<Integer,String> seqcontain;
	public static HashMap<String,Float> itemweight;
	static HashMap<Integer, Float> seqsmw; 
	//since the seq is the same seq so smw of each seq will not calaculate in findsp function
	private static ArrayList<String> candidates;
	//the candidate with n+1 length of e
	//static ArrayList<String> lastUBSP;
	//lastUBSP is the set of length-n UBSP
	static Integer n;
	static String e;
	static Float tsmw;

	
	static void main() throws IOException {
		//Initialize the length n+1 SP pattern set and UBSP pattern set 
		ArrayList<String> SP = new ArrayList<String>();
		ArrayList<String> UBSP = new ArrayList<String>();
		candidates = new ArrayList<String>();

		for (Integer i : itemDB.keySet()) {
			//for each seq in this itemDB, i is the id of this sequence
			String seq = itemDB.get(i);//the elements in itemDB are ordered (ID)
			adjcandidates(seq, n, i);
		}
		for(int i = 0; i<candidates.size(); i++) {
			String candidate = candidates.get(i);//the elements in candidates are unordered
			
			//System.out.println(lastUBSP);
			/*if(UBcheck(lastUBSP,candidate)==false) {
				continue;
			}*/
			//following part of main() is mainly copied from the main() of main-fun
			
			if(calwsup(candidate, tsmw, itemDB)) {
				if(ifrepeat(candidate,SP)==0) {
					SP.add(candidate);
				}
				
			}
			if(calswub(candidate, tsmw, itemDB, seqsmw)) {
				if(ifrepeat(candidate,UBSP)==0) {
					UBSP.add(candidate);
				}
			}
		}
		for(int m = 0; m<UBSP.size();m++) {
			String candidate = UBSP.get(m);
			HashMap<Integer, String> seqcontain = contain(candidate, itemDB);
			HashMap<Integer, String> newitemDB = new HashMap<Integer, String>();
			for (Integer j : seqcontain.keySet()) {
				String seq = itemDB.get(j);
				if(seq.length()>=(n+2)) {
					newitemDB.put(j, seq);
				}
			}
			//Find-SP();
			
			findsp.candidates = null;
			findsp.itemDB = newitemDB;
			//findsp.lastUBSP = UBSP;
			findsp.seqcontain = seqcontain;
			findsp.n = n + 1;
			findsp.e = candidate;
			MemoryLogger.getInstance().checkMemory();//
			findsp.main();
				
		}

		writefile(filePathS, SP);
	}
	
	private static boolean isunique(String candidate, ArrayList<String> candidateset) {
		if(candidateset==null) {
			return true;
		}else {
		for(int i = 0;i<candidateset.size();i++) {
			String temp = candidateset.get(i);
			if(candidate == temp) {
				return false;
			}
		}
		return true;
	}
		}
	
	private static boolean unique(Integer A, ArrayList<Integer> B) {
		if(B==null) {
			return true;
		}else {
		for(int i = 0;i<B.size();i++) {
			Integer temp = B.get(i);
			if(A == temp) {
				return false;
			}
		}
		return true;
	}
		}

	
	private static void adjcandidates(String seq, Integer n, Integer id){
		//there in adjcandidates function i use hashmap "seqcontain" to quickly generate candidates without scanning the sequence
		int seqlength = seq.length();
		String positions = seqcontain.get(id);
		String presup = new String("");
		String postsup = new String("");
		String tempindex = new String();
		for(int i =0; i< positions.length(); i++) {
			char temp = positions.charAt(i);
			if(temp!='-') {
				tempindex = tempindex + String.valueOf(temp);
			}else {
				int j = Integer.parseInt(tempindex);
			//for each positions that the pattern "e" locate in the sequence
			//j is the position that "e" in this sequence
			 /*if((j-1)>=0) {
				 //if the presup-candidate exist	 
				 presup = String.valueOf(seq.charAt(j-1)) + e;
				 if(isunique(presup,candidates)) {
					 candidates.add(presup);
				 }
			 }*/
			 if((j+n+1)<=seqlength) {
				 //if the postsup-candidate exist
				 postsup = e + String.valueOf(seq.charAt(j+n));
				 if(isunique(postsup,candidates)) {
					 candidates.add(postsup);
				 }
			 }
			 tempindex = new String();
			 }
		}
		MemoryLogger.getInstance().checkMemory();//
	}
	
	public static String removeCharAt(String s, int pos) {
		return s.substring(0, pos) + s.substring(pos + 1);
	}
	   
	/*private static boolean UBcheck(ArrayList<String> nUBSP, String candidate) {
		String presub = removeCharAt(candidate,candidate.length()-1);
		String postsub = removeCharAt(candidate,0);
		if((nUBSP.contains(presub))||(nUBSP.contains(postsub))) {
			return true;
		}else {
			return false;
		}
	}*/

//following functions are mainly copied from mainfun
	public static void writefile(String filePath, ArrayList<String> patterns){

        try{
            File file = new File(filePath);
            FileOutputStream fos = null;
            if(!file.exists()){
                file.createNewFile();
                fos = new FileOutputStream(file);
            }else{
                fos = new FileOutputStream(file,true);
            }
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            for(int i = 0; i<patterns.size();i++){
                String pattern = patterns.get(i);
                osw.write(pattern);
                osw.write("\r\n");
            }
            osw.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	private static Float calwv(String s) {
		Float totalw = (float) 0;
		for(int i = 0; i<s.length();i++) {
			String item = String.valueOf(s.charAt(i));
			totalw = totalw + itemweight.get(item);
		}
		totalw = totalw/((float)s.length());
		return totalw;
	}
	
	private static boolean calwsup(String s, Float tsmw, HashMap<Integer,String> DB) {
		//here this function only used in Main-Fun. In Find-SP the calwsup function will enhance the method to
		//find which sequence contain the candidate
		//first calculate weighted value of the candidate.
		Float Ws = calwv(s);
		//then check the num of seq that conatain s
		int num = quickcontain(s,DB);

		Float wsup = (Ws*num)/tsmw;
		if(wsup>threshold) {
			return true;
		}else {
			return false;
		}
	}
	
	private static boolean calswub(String s, Float tsmw, HashMap<Integer,String> DB, HashMap<Integer,Float> smw){
		/*???here this function i didn't use inheritance and polymorphism to return boolean and "seqcontain" hashmap
		 * which can Simplify the code
		 * i am not sure whether it will effect the efficiency of algorithm*/
		HashMap<Integer, String> seqcontain = contain(s, DB);
		ArrayList<Integer> idlist = new ArrayList<Integer>();//
		Float totalsmw = (float) 0;
		for(Integer i : seqcontain.keySet()) {
			if(unique(i,idlist)) {//
				idlist.add(i);//
				totalsmw = totalsmw + smw.get(i);
			}
			
		}
		Float swub = totalsmw/tsmw;
		if(swub>threshold) {
			return true;
		}else {
			return false;
		}
	}
	
	//since in findSP function the candidate is not a single item, we use "seqcontain" of its subpattern "e" to quick check
	private static HashMap<Integer,String> contain(String candidate, HashMap<Integer,String> DB) {
		HashMap<Integer, String> newseqcontain = new HashMap<Integer, String>();


		for(Integer i : DB.keySet()) {//here, "i" is the id of the sequence in DB
			String seq = DB.get(i);
			int seqlength = seq.length();
			String oldpositions = seqcontain.get(i);

			String newposition = "";//here, "position" mean the place that candidate shown in this sequence
			int iscontain = 0;
			String oldindex = new String();
			for(int j = 0; j<oldpositions.length();j++) {
				char temp = oldpositions.charAt(j);

				if(temp!='-') {
					oldindex = oldindex + String.valueOf(temp);
				}else {
					if(oldindex.length()==0) {
						continue;
					}
					int formerposition = Integer.parseInt(oldindex);

				/*since the candidate is a super-pattern of "e", we just check the presuper-pattern and the 
				 * postsuper-pattern of "e" in this sequence is candidate or not*/
				if((formerposition-1)>=0){
					String temppresup = String.valueOf(seq.charAt(formerposition-1)) + e;

					if(temppresup.equals(candidate)) {
						iscontain=1;
						newposition = newposition + String.valueOf(formerposition-1) + "-";
					}
				}
				if((formerposition+n+1)<=seqlength){
					String temppostsup = e + String.valueOf(seq.charAt(formerposition+n));

					if(temppostsup.equals(candidate)) {
						iscontain=1;
						newposition = newposition + String.valueOf(formerposition) + "-";

					}
				}
				oldindex = new String();
			}
		}
			if(iscontain==1) {
				newseqcontain.put(i, newposition);

			}
		}
		MemoryLogger.getInstance().checkMemory();//
		return newseqcontain;
	}
	
	private static Integer quickcontain(String s, HashMap<Integer,String> DB) {
		//this contain function only check the number of seq that contain the candidate
		Integer num = 0;
		ArrayList<Integer> idlist = new ArrayList<Integer>();//
		for(Integer i : DB.keySet()) {
			String seq = DB.get(i);
			if(seq==null) {
				continue;
			}
			if(seq.contains(s)&&(unique(i,idlist))) {
				num++;
				idlist.add(i);
			}
		}
		return num;
	}
	
	private static Integer ifrepeat(String s, ArrayList<String> set) {
		//this contain function only check the number of seq that contain the candidate
		for(int i = 0; i<set.size();i++) {
			String seq = set.get(i);
			if(seq==null) {
				continue;
			}
			if(seq.contains(s)) {
				return 1;
			}
		}
		return 0;
	}
}
	

